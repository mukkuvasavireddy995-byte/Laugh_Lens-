MERGE INTO effects (code,name,emoji,css_class,description) KEY(code) VALUES
('party','Disco Face','🪩','fx-party','Neon party energy'),
('alien','Alien Mode','👽','fx-alien','Out-of-this-world colors'),
('doggo','Puppy Vibes','🐶','fx-doggo','Warm puppy-style filter'),
('banana','Banana Panic','🍌','fx-banana','Yellow chaos mode'),
('meme','Meme Zoom','😂','fx-meme','High-contrast meme look'),
('heart','Heart Burst','💖','fx-heart','Romantic sparkle chaos'),
('ghost','Ghost Cam','👻','fx-ghost','Spooky ghostly colors'),
('nerd','Mega Nerd','🤓','fx-nerd','Smart and silly'),
('crown','Royal Snap','👑','fx-crown','Royal glow'),
('rainbow','Rainbow Beam','🌈','fx-rainbow','Colorful rainbow mood');